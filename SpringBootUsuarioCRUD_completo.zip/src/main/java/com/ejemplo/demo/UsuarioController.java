package com.ejemplo.demo;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    private final UsuarioRepository repo;

    public UsuarioController(UsuarioRepository repo) {
        this.repo = repo;
    }

    @PostMapping
    public Usuario crear(@RequestBody Usuario usuario) {
        return repo.crear(usuario.getNombre(), usuario.getCorreo(), usuario.getContrasena());
    }

    @GetMapping
    public List<Usuario> obtenerTodos() {
        return repo.obtenerTodos();
    }

    @GetMapping("/{id}")
    public Usuario obtenerPorId(@PathVariable Long id) {
        return repo.obtenerPorId(id).orElse(null);
    }

    @PutMapping("/{id}")
    public Usuario actualizar(@PathVariable Long id, @RequestBody Usuario usuario) {
        return repo.actualizar(id, usuario.getNombre(), usuario.getCorreo());
    }

    @DeleteMapping("/{id}")
    public String eliminar(@PathVariable Long id) {
        boolean eliminado = repo.eliminar(id);
        return eliminado ? "Usuario eliminado" : "Usuario no encontrado";
    }
}
